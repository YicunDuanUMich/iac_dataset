exports.handler = async (event) => {
    // Lambda handler code
    console.log(JSON.stringify(event, 0, null))
  }